﻿namespace AppSim_Ana_2c
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblLojaDeGames = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtPeco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtJogo03 = new System.Windows.Forms.TextBox();
            this.txtJogo02 = new System.Windows.Forms.TextBox();
            this.txtJogo01 = new System.Windows.Forms.TextBox();
            this.lblPreco03 = new System.Windows.Forms.Label();
            this.lblPreco02 = new System.Windows.Forms.Label();
            this.lblPreco01 = new System.Windows.Forms.Label();
            this.lblJogo03 = new System.Windows.Forms.Label();
            this.lblJogo02 = new System.Windows.Forms.Label();
            this.lblJogo01 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblResultado5 = new System.Windows.Forms.Label();
            this.lblResultado4 = new System.Windows.Forms.Label();
            this.lblResultado3 = new System.Windows.Forms.Label();
            this.lblResultado2 = new System.Windows.Forms.Label();
            this.lblResultado1 = new System.Windows.Forms.Label();
            this.lblParecela5 = new System.Windows.Forms.Label();
            this.lblParecela4 = new System.Windows.Forms.Label();
            this.lblParecela3 = new System.Windows.Forms.Label();
            this.lblParecela2 = new System.Windows.Forms.Label();
            this.lblParecela1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(163)))), ((int)(((byte)(195)))));
            this.panel1.Controls.Add(this.lblLojaDeGames);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 108);
            this.panel1.TabIndex = 1;
            // 
            // lblLojaDeGames
            // 
            this.lblLojaDeGames.AutoSize = true;
            this.lblLojaDeGames.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLojaDeGames.Location = new System.Drawing.Point(277, 42);
            this.lblLojaDeGames.Name = "lblLojaDeGames";
            this.lblLojaDeGames.Size = new System.Drawing.Size(276, 35);
            this.lblLojaDeGames.TabIndex = 0;
            this.lblLojaDeGames.Text = "LOJA DE GAMES";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.panel2.Controls.Add(this.txtPeco3);
            this.panel2.Controls.Add(this.txtPreco2);
            this.panel2.Controls.Add(this.txtPreco1);
            this.panel2.Controls.Add(this.txtJogo03);
            this.panel2.Controls.Add(this.txtJogo02);
            this.panel2.Controls.Add(this.txtJogo01);
            this.panel2.Controls.Add(this.lblPreco03);
            this.panel2.Controls.Add(this.lblPreco02);
            this.panel2.Controls.Add(this.lblPreco01);
            this.panel2.Controls.Add(this.lblJogo03);
            this.panel2.Controls.Add(this.lblJogo02);
            this.panel2.Controls.Add(this.lblJogo01);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(53, 138);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(691, 195);
            this.panel2.TabIndex = 2;
            // 
            // txtPeco3
            // 
            this.txtPeco3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtPeco3.Location = new System.Drawing.Point(313, 121);
            this.txtPeco3.Name = "txtPeco3";
            this.txtPeco3.Size = new System.Drawing.Size(116, 20);
            this.txtPeco3.TabIndex = 12;
            // 
            // txtPreco2
            // 
            this.txtPreco2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtPreco2.Location = new System.Drawing.Point(313, 77);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(116, 20);
            this.txtPreco2.TabIndex = 11;
            // 
            // txtPreco1
            // 
            this.txtPreco1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtPreco1.Location = new System.Drawing.Point(313, 24);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(116, 20);
            this.txtPreco1.TabIndex = 10;
            // 
            // txtJogo03
            // 
            this.txtJogo03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtJogo03.Location = new System.Drawing.Point(87, 121);
            this.txtJogo03.Name = "txtJogo03";
            this.txtJogo03.Size = new System.Drawing.Size(116, 20);
            this.txtJogo03.TabIndex = 9;
            // 
            // txtJogo02
            // 
            this.txtJogo02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtJogo02.Location = new System.Drawing.Point(87, 77);
            this.txtJogo02.Name = "txtJogo02";
            this.txtJogo02.Size = new System.Drawing.Size(116, 20);
            this.txtJogo02.TabIndex = 8;
            // 
            // txtJogo01
            // 
            this.txtJogo01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(86)))), ((int)(((byte)(118)))));
            this.txtJogo01.Location = new System.Drawing.Point(87, 24);
            this.txtJogo01.Name = "txtJogo01";
            this.txtJogo01.Size = new System.Drawing.Size(116, 20);
            this.txtJogo01.TabIndex = 7;
            // 
            // lblPreco03
            // 
            this.lblPreco03.AutoSize = true;
            this.lblPreco03.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco03.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPreco03.Location = new System.Drawing.Point(236, 121);
            this.lblPreco03.Name = "lblPreco03";
            this.lblPreco03.Size = new System.Drawing.Size(70, 16);
            this.lblPreco03.TabIndex = 6;
            this.lblPreco03.Text = "Preço 03";
            // 
            // lblPreco02
            // 
            this.lblPreco02.AutoSize = true;
            this.lblPreco02.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco02.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPreco02.Location = new System.Drawing.Point(236, 77);
            this.lblPreco02.Name = "lblPreco02";
            this.lblPreco02.Size = new System.Drawing.Size(70, 16);
            this.lblPreco02.TabIndex = 5;
            this.lblPreco02.Text = "Preço 02";
            // 
            // lblPreco01
            // 
            this.lblPreco01.AutoSize = true;
            this.lblPreco01.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco01.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblPreco01.Location = new System.Drawing.Point(236, 23);
            this.lblPreco01.Name = "lblPreco01";
            this.lblPreco01.Size = new System.Drawing.Size(70, 16);
            this.lblPreco01.TabIndex = 4;
            this.lblPreco01.Text = "Preço 01";
            // 
            // lblJogo03
            // 
            this.lblJogo03.AutoSize = true;
            this.lblJogo03.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo03.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblJogo03.Location = new System.Drawing.Point(14, 121);
            this.lblJogo03.Name = "lblJogo03";
            this.lblJogo03.Size = new System.Drawing.Size(63, 16);
            this.lblJogo03.TabIndex = 3;
            this.lblJogo03.Text = "Jogo 03";
            // 
            // lblJogo02
            // 
            this.lblJogo02.AutoSize = true;
            this.lblJogo02.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo02.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblJogo02.Location = new System.Drawing.Point(14, 77);
            this.lblJogo02.Name = "lblJogo02";
            this.lblJogo02.Size = new System.Drawing.Size(63, 16);
            this.lblJogo02.TabIndex = 2;
            this.lblJogo02.Text = "Jogo 02";
            // 
            // lblJogo01
            // 
            this.lblJogo01.AutoSize = true;
            this.lblJogo01.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJogo01.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblJogo01.Location = new System.Drawing.Point(14, 23);
            this.lblJogo01.Name = "lblJogo01";
            this.lblJogo01.Size = new System.Drawing.Size(63, 16);
            this.lblJogo01.TabIndex = 1;
            this.lblJogo01.Text = "Jogo 01";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(230)))), ((int)(((byte)(244)))));
            this.panel4.Controls.Add(this.lblResultado5);
            this.panel4.Controls.Add(this.lblResultado4);
            this.panel4.Controls.Add(this.lblResultado3);
            this.panel4.Controls.Add(this.lblResultado2);
            this.panel4.Controls.Add(this.lblResultado1);
            this.panel4.Controls.Add(this.lblParecela5);
            this.panel4.Controls.Add(this.lblParecela4);
            this.panel4.Controls.Add(this.lblParecela3);
            this.panel4.Controls.Add(this.lblParecela2);
            this.panel4.Controls.Add(this.lblParecela1);
            this.panel4.Location = new System.Drawing.Point(435, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(256, 195);
            this.panel4.TabIndex = 0;
            // 
            // lblResultado5
            // 
            this.lblResultado5.AutoSize = true;
            this.lblResultado5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado5.Location = new System.Drawing.Point(144, 162);
            this.lblResultado5.Name = "lblResultado5";
            this.lblResultado5.Size = new System.Drawing.Size(14, 16);
            this.lblResultado5.TabIndex = 14;
            this.lblResultado5.Text = "-";
            // 
            // lblResultado4
            // 
            this.lblResultado4.AutoSize = true;
            this.lblResultado4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado4.Location = new System.Drawing.Point(144, 122);
            this.lblResultado4.Name = "lblResultado4";
            this.lblResultado4.Size = new System.Drawing.Size(14, 16);
            this.lblResultado4.TabIndex = 13;
            this.lblResultado4.Text = "-";
            // 
            // lblResultado3
            // 
            this.lblResultado3.AutoSize = true;
            this.lblResultado3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado3.Location = new System.Drawing.Point(144, 92);
            this.lblResultado3.Name = "lblResultado3";
            this.lblResultado3.Size = new System.Drawing.Size(14, 16);
            this.lblResultado3.TabIndex = 12;
            this.lblResultado3.Text = "-";
            // 
            // lblResultado2
            // 
            this.lblResultado2.AutoSize = true;
            this.lblResultado2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado2.Location = new System.Drawing.Point(144, 55);
            this.lblResultado2.Name = "lblResultado2";
            this.lblResultado2.Size = new System.Drawing.Size(14, 16);
            this.lblResultado2.TabIndex = 11;
            this.lblResultado2.Text = "-";
            // 
            // lblResultado1
            // 
            this.lblResultado1.AutoSize = true;
            this.lblResultado1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblResultado1.Location = new System.Drawing.Point(144, 25);
            this.lblResultado1.Name = "lblResultado1";
            this.lblResultado1.Size = new System.Drawing.Size(14, 16);
            this.lblResultado1.TabIndex = 10;
            this.lblResultado1.Text = "-";
            // 
            // lblParecela5
            // 
            this.lblParecela5.AutoSize = true;
            this.lblParecela5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParecela5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblParecela5.Location = new System.Drawing.Point(18, 162);
            this.lblParecela5.Name = "lblParecela5";
            this.lblParecela5.Size = new System.Drawing.Size(100, 16);
            this.lblParecela5.TabIndex = 9;
            this.lblParecela5.Text = "5 parcela de ";
            // 
            // lblParecela4
            // 
            this.lblParecela4.AutoSize = true;
            this.lblParecela4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParecela4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblParecela4.Location = new System.Drawing.Point(18, 125);
            this.lblParecela4.Name = "lblParecela4";
            this.lblParecela4.Size = new System.Drawing.Size(100, 16);
            this.lblParecela4.TabIndex = 8;
            this.lblParecela4.Text = "4 parcela de ";
            // 
            // lblParecela3
            // 
            this.lblParecela3.AutoSize = true;
            this.lblParecela3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParecela3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblParecela3.Location = new System.Drawing.Point(18, 92);
            this.lblParecela3.Name = "lblParecela3";
            this.lblParecela3.Size = new System.Drawing.Size(100, 16);
            this.lblParecela3.TabIndex = 7;
            this.lblParecela3.Text = "3 parcela de ";
            // 
            // lblParecela2
            // 
            this.lblParecela2.AutoSize = true;
            this.lblParecela2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParecela2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblParecela2.Location = new System.Drawing.Point(18, 55);
            this.lblParecela2.Name = "lblParecela2";
            this.lblParecela2.Size = new System.Drawing.Size(100, 16);
            this.lblParecela2.TabIndex = 6;
            this.lblParecela2.Text = "2 parcela de ";
            // 
            // lblParecela1
            // 
            this.lblParecela1.AutoSize = true;
            this.lblParecela1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParecela1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblParecela1.Location = new System.Drawing.Point(18, 23);
            this.lblParecela1.Name = "lblParecela1";
            this.lblParecela1.Size = new System.Drawing.Size(100, 16);
            this.lblParecela1.TabIndex = 5;
            this.lblParecela1.Text = "1 parcela de ";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(40)))), ((int)(((byte)(57)))));
            this.btnCalcular.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCalcular.Location = new System.Drawing.Point(186, 363);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(443, 45);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmQuestao01";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblLojaDeGames;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPreco03;
        private System.Windows.Forms.Label lblPreco02;
        private System.Windows.Forms.Label lblPreco01;
        private System.Windows.Forms.Label lblJogo03;
        private System.Windows.Forms.Label lblJogo02;
        private System.Windows.Forms.Label lblJogo01;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtPeco3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtJogo03;
        private System.Windows.Forms.TextBox txtJogo02;
        private System.Windows.Forms.TextBox txtJogo01;
        private System.Windows.Forms.Label lblParecela1;
        private System.Windows.Forms.Label lblParecela5;
        private System.Windows.Forms.Label lblParecela4;
        private System.Windows.Forms.Label lblParecela3;
        private System.Windows.Forms.Label lblParecela2;
        private System.Windows.Forms.Label lblResultado5;
        private System.Windows.Forms.Label lblResultado4;
        private System.Windows.Forms.Label lblResultado3;
        private System.Windows.Forms.Label lblResultado2;
        private System.Windows.Forms.Label lblResultado1;
        private System.Windows.Forms.Button btnCalcular;
    }
}

